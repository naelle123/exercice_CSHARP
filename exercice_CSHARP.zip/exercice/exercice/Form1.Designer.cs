﻿namespace exercice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_LeftList = new System.Windows.Forms.ListBox();
            this.lb_RightList = new System.Windows.Forms.ListBox();
            this.bt_RightToLeft = new System.Windows.Forms.Button();
            this.bt_RemoveLeftElement = new System.Windows.Forms.Button();
            this.bt_AddLeftList = new System.Windows.Forms.Button();
            this.bt_AddRightList = new System.Windows.Forms.Button();
            this.bt_RemoveRightElement = new System.Windows.Forms.Button();
            this.bt_LeftToRight = new System.Windows.Forms.Button();
            this.bt_exit = new System.Windows.Forms.Button();
            this.tb_left = new System.Windows.Forms.TextBox();
            this.tb_rigth = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_LeftList
            // 
            this.lb_LeftList.FormattingEnabled = true;
            this.lb_LeftList.ItemHeight = 16;
            this.lb_LeftList.Location = new System.Drawing.Point(37, 125);
            this.lb_LeftList.Name = "lb_LeftList";
            this.lb_LeftList.Size = new System.Drawing.Size(256, 372);
            this.lb_LeftList.TabIndex = 0;
            // 
            // lb_RightList
            // 
            this.lb_RightList.FormattingEnabled = true;
            this.lb_RightList.ItemHeight = 16;
            this.lb_RightList.Location = new System.Drawing.Point(480, 125);
            this.lb_RightList.Name = "lb_RightList";
            this.lb_RightList.Size = new System.Drawing.Size(256, 372);
            this.lb_RightList.TabIndex = 0;
            // 
            // bt_RightToLeft
            // 
            this.bt_RightToLeft.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_RightToLeft.Location = new System.Drawing.Point(334, 334);
            this.bt_RightToLeft.Name = "bt_RightToLeft";
            this.bt_RightToLeft.Size = new System.Drawing.Size(98, 50);
            this.bt_RightToLeft.TabIndex = 1;
            this.bt_RightToLeft.Text = "<<";
            this.bt_RightToLeft.UseVisualStyleBackColor = true;
            this.bt_RightToLeft.Click += new System.EventHandler(this.bt_RightToLeft_Click);
            // 
            // bt_RemoveLeftElement
            // 
            this.bt_RemoveLeftElement.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_RemoveLeftElement.Location = new System.Drawing.Point(219, 588);
            this.bt_RemoveLeftElement.Name = "bt_RemoveLeftElement";
            this.bt_RemoveLeftElement.Size = new System.Drawing.Size(74, 50);
            this.bt_RemoveLeftElement.TabIndex = 1;
            this.bt_RemoveLeftElement.Text = "-";
            this.bt_RemoveLeftElement.UseVisualStyleBackColor = true;
            this.bt_RemoveLeftElement.Click += new System.EventHandler(this.bt_RemoveLeftElement_Click);
            // 
            // bt_AddLeftList
            // 
            this.bt_AddLeftList.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_AddLeftList.Location = new System.Drawing.Point(37, 588);
            this.bt_AddLeftList.Name = "bt_AddLeftList";
            this.bt_AddLeftList.Size = new System.Drawing.Size(74, 50);
            this.bt_AddLeftList.TabIndex = 1;
            this.bt_AddLeftList.Text = "+";
            this.bt_AddLeftList.UseVisualStyleBackColor = true;
            this.bt_AddLeftList.Click += new System.EventHandler(this.bt_AddLeftList_Click);
            // 
            // bt_AddRightList
            // 
            this.bt_AddRightList.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_AddRightList.Location = new System.Drawing.Point(480, 588);
            this.bt_AddRightList.Name = "bt_AddRightList";
            this.bt_AddRightList.Size = new System.Drawing.Size(74, 50);
            this.bt_AddRightList.TabIndex = 1;
            this.bt_AddRightList.Text = "+";
            this.bt_AddRightList.UseVisualStyleBackColor = true;
            this.bt_AddRightList.Click += new System.EventHandler(this.bt_AddRightList_Click);
            // 
            // bt_RemoveRightElement
            // 
            this.bt_RemoveRightElement.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_RemoveRightElement.Location = new System.Drawing.Point(662, 588);
            this.bt_RemoveRightElement.Name = "bt_RemoveRightElement";
            this.bt_RemoveRightElement.Size = new System.Drawing.Size(74, 50);
            this.bt_RemoveRightElement.TabIndex = 1;
            this.bt_RemoveRightElement.Text = "-";
            this.bt_RemoveRightElement.UseVisualStyleBackColor = true;
            this.bt_RemoveRightElement.Click += new System.EventHandler(this.bt_RemoveRightElement_Click);
            // 
            // bt_LeftToRight
            // 
            this.bt_LeftToRight.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_LeftToRight.Location = new System.Drawing.Point(334, 219);
            this.bt_LeftToRight.Name = "bt_LeftToRight";
            this.bt_LeftToRight.Size = new System.Drawing.Size(98, 50);
            this.bt_LeftToRight.TabIndex = 1;
            this.bt_LeftToRight.Text = ">>";
            this.bt_LeftToRight.UseVisualStyleBackColor = true;
            this.bt_LeftToRight.Click += new System.EventHandler(this.bt_LeftToRight_Click);
            // 
            // bt_exit
            // 
            this.bt_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_exit.Location = new System.Drawing.Point(334, 667);
            this.bt_exit.Name = "bt_exit";
            this.bt_exit.Size = new System.Drawing.Size(98, 50);
            this.bt_exit.TabIndex = 1;
            this.bt_exit.Text = "Quitter";
            this.bt_exit.UseVisualStyleBackColor = true;
            this.bt_exit.Click += new System.EventHandler(this.bt_exit_Click);
            // 
            // tb_left
            // 
            this.tb_left.Font = new System.Drawing.Font("Arial Black", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_left.Location = new System.Drawing.Point(61, 521);
            this.tb_left.Multiline = true;
            this.tb_left.Name = "tb_left";
            this.tb_left.Size = new System.Drawing.Size(197, 36);
            this.tb_left.TabIndex = 2;
            // 
            // tb_rigth
            // 
            this.tb_rigth.Font = new System.Drawing.Font("Arial Black", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_rigth.Location = new System.Drawing.Point(504, 521);
            this.tb_rigth.Multiline = true;
            this.tb_rigth.Name = "tb_rigth";
            this.tb_rigth.Size = new System.Drawing.Size(197, 36);
            this.tb_rigth.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(312, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "exercice";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(762, 738);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_rigth);
            this.Controls.Add(this.tb_left);
            this.Controls.Add(this.bt_RemoveRightElement);
            this.Controls.Add(this.bt_AddRightList);
            this.Controls.Add(this.bt_AddLeftList);
            this.Controls.Add(this.bt_RemoveLeftElement);
            this.Controls.Add(this.bt_exit);
            this.Controls.Add(this.bt_LeftToRight);
            this.Controls.Add(this.bt_RightToLeft);
            this.Controls.Add(this.lb_RightList);
            this.Controls.Add(this.lb_LeftList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_LeftList;
        private System.Windows.Forms.ListBox lb_RightList;
        private System.Windows.Forms.Button bt_RightToLeft;
        private System.Windows.Forms.Button bt_RemoveLeftElement;
        private System.Windows.Forms.Button bt_AddLeftList;
        private System.Windows.Forms.Button bt_AddRightList;
        private System.Windows.Forms.Button bt_RemoveRightElement;
        private System.Windows.Forms.Button bt_LeftToRight;
        private System.Windows.Forms.Button bt_exit;
        private System.Windows.Forms.TextBox tb_left;
        private System.Windows.Forms.TextBox tb_rigth;
        private System.Windows.Forms.Label label1;
    }
}

