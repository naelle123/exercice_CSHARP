﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void AddToList(ListBox lb, TextBox tb)
        {
            if(!string.IsNullOrEmpty(tb.Text))
            {
                lb.Items.Add(tb.Text);
                tb.Text = "";
                tb.Focus();
            }
        }

        private void bt_AddLeftList_Click(object sender, EventArgs e)
        {
            AddToList(this.lb_LeftList, this.tb_left);
        }

        private void bt_AddRightList_Click(object sender, EventArgs e)
        {
            AddToList(this.lb_RightList, this.tb_rigth);
        }
        private void RemoveFromList(ListBox lb)
        {
            if(lb.SelectedIndex >= 0)
            {
                lb.Items.RemoveAt(lb.SelectedIndex);
            }
        }

        private void bt_RemoveLeftElement_Click(object sender, EventArgs e)
        {
            RemoveFromList(this.lb_LeftList);
        }

        private void bt_RemoveRightElement_Click(object sender, EventArgs e)
        {
            RemoveFromList(this.lb_RightList);
        }
        private void SwitchElement(ListBox lb_from, ListBox lb_destination)
        {
            if(lb_from.SelectedIndex >= 0)
            {
                lb_destination.Items.Add(lb_from.SelectedItem);
                lb_from.Items.Remove(lb_from.SelectedItem);
            }
        }

        private void bt_LeftToRight_Click(object sender, EventArgs e)
        {
            SwitchElement(this.lb_LeftList, this.lb_RightList);
        }

        private void bt_RightToLeft_Click(object sender, EventArgs e)
        {
            SwitchElement(this.lb_RightList, this.lb_LeftList);
        }

        private void bt_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
